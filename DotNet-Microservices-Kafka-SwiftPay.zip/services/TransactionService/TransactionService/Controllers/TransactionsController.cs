using Microsoft.AspNetCore.Mvc;
using TransactionService.Models;

namespace TransactionService.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TransactionsController : ControllerBase
{
    private static readonly List<Transaction> Transactions = new();

    [HttpGet]
    public IActionResult GetAll() => Ok(Transactions);

    [HttpPost]
    public IActionResult Create(Transaction tx)
    {
        tx.Id = Guid.NewGuid();
        tx.Timestamp = DateTime.UtcNow;
        tx.Status = "Pending";
        Transactions.Add(tx);
        return CreatedAtAction(nameof(GetAll), new { id = tx.Id }, tx);
    }
}